<div class="container">
    <div class="row">
        <div class="span3">
            <div class="well sidebar-nav transparent-box">
                <ul class="nav nav-list">
                    <li class="nav-header"><i class="icon-cog icon-white"></i> ACCOUNT CONTROLS</li>
                    <li class="active"><a href="Accounts/ticket_list">Call Logs</a></li>
                    <li><a href="Agents/agent_registration">Agent Registration</a></li>
                    <li><a href="Agents/contractors">List of Contractors</a></li>
                    <li class="nav-header"><i class="icon-cog icon-white"></i> REPORTS</li>
                    <li><a href="#">Finished Tickets</a></li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                    <li class="nav-header">Sidebar</li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                    <li><a href="#">Link</a></li>
                </ul>
            </div><!--/.well -->
        </div><!--/span-->
        <div class="span9" id="contents">
        </div>
    </div><!-- .row -->
</div><!-- .container -->