<div class='push'></div>
</div>
<footer>
    <i class="icon-signal icon-white"></i> Cable Link - Your Link to World Class Entertainment<br />
    <b>Copyright &COPY; 2013</b>
    <div><b>Updated August 26, 2013</b></div>
</footer>
</body>
</html>